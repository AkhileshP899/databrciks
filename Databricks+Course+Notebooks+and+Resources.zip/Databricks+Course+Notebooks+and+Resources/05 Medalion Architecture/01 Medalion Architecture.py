# Databricks notebook source
# MAGIC %md
# MAGIC # Medalion Architecture
# MAGIC
# MAGIC For detailed guidance on the Medalion Architecture please refer to the following links:
# MAGIC
# MAGIC - https://www.databricks.com/glossary/medallion-architecture
# MAGIC - https://docs.databricks.com/lakehouse/medallion.html