# Databricks notebook source
# MAGIC %md
# MAGIC # Links and Resources
# MAGIC
# MAGIC #### Resources
# MAGIC * What is CI/CD on Azure Databricks? https://learn.microsoft.com/en-us/azure/databricks/dev-tools/index-ci-cd
# MAGIC * Azure Pipelines: https://learn.microsoft.com/en-us/azure/devops/pipelines/get-started/what-is-azure-pipelines?view=azure-devops