# Databricks notebook source
# MAGIC %md
# MAGIC # Links and Resources
# MAGIC
# MAGIC #### Resources
# MAGIC * Databricks CLI https://learn.microsoft.com/en-us/azure/databricks/dev-tools/cli/