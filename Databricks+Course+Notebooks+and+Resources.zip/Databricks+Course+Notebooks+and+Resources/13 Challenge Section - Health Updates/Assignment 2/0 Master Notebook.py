# Databricks notebook source
# MAGIC %md
# MAGIC # Assignment 2 - Health Updates (Solutions)
# MAGIC ## This is the master notebook
# MAGIC ### You can schedule this notebook to run the "Bronze to Silver" and "Silver to Gold" Notebooks

# COMMAND ----------

dbutils.notebook.run("/Users/azure.mv14@gmail.com/13 Assignments/Assignment 2/1 Bronze to Silver", 60)

# COMMAND ----------

dbutils.notebook.run("/Users/azure.mv14@gmail.com/13 Assignments/Assignment 2/2 Silver to Gold", 60)