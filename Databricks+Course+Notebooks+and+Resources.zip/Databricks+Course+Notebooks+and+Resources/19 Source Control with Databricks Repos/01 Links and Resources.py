# Databricks notebook source
# MAGIC %md
# MAGIC # Links and Resources
# MAGIC
# MAGIC #### Resources
# MAGIC * Get started with Azure DevOps https://learn.microsoft.com/en-us/training/paths/evolve-your-devops-practices/
# MAGIC * Databricks Repos https://learn.microsoft.com/en-us/azure/databricks/repos/
# MAGIC * Getting Started with Databricks Repos https://www.youtube.com/watch?v=k9Kuz19ByNg
# MAGIC * Azure Repos Documentation https://learn.microsoft.com/en-us/azure/devops/repos/?view=azure-devops