# Databricks notebook source
# MAGIC %md
# MAGIC #### Resources
# MAGIC
# MAGIC * Create and run Databricks Jobs: https://learn.microsoft.com/en-us/azure/databricks/workflows/jobs/create-run-jobs