# Databricks notebook source
# MAGIC %md
# MAGIC #### Resources
# MAGIC
# MAGIC * Task Context: https://learn.microsoft.com/en-us/azure/databricks/workflows/jobs/share-task-context
# MAGIC * Task Parameter Variables: https://learn.microsoft.com/en-us/azure/databricks/workflows/jobs/task-parameter-variables
# MAGIC * Databricks Widgets: https://learn.microsoft.com/en-us/azure/databricks/notebooks/widgets