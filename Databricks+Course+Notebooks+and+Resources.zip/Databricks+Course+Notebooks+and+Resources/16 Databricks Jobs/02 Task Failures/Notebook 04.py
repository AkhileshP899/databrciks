# Databricks notebook source
# Intentionally raising an error
prnt('This is Notebook 04')