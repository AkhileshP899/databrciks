# Databricks notebook source
# MAGIC %md
# MAGIC # How to use Databricks Notebooks
# MAGIC
# MAGIC #### Resources
# MAGIC * https://learn.microsoft.com/en-us/azure/databricks/notebooks/
# MAGIC * https://learn.microsoft.com/en-us/azure/databricks/dev-tools/databricks-utils