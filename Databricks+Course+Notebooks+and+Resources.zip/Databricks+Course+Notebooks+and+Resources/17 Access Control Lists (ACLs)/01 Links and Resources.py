# Databricks notebook source
# MAGIC %md
# MAGIC #### Resources
# MAGIC
# MAGIC * Access Control: https://learn.microsoft.com/en-us/azure/databricks/security/auth-authz/access-control/